# Smart Class Complaint System

## Run
```bash
python -m venv venv
venv\\Scripts\\activate
pip install -r requirements.txt
copy .env.example .env
python app.py
```
Open http://127.0.0.1:5000

## Default admin
Username: `admin`
Password: `admin123`

Change the default password before production use.

## SMTP
Configure `.env` with SMTP credentials. For Gmail, use an App Password.

## Workflow
Admin creates a location -> downloads its QR -> student scans QR -> location is prefilled -> student writes issue -> complaint ID is generated -> optional email notification -> admin reviews -> student tracks status.

No student name, roll number, student ID, phone, email, address, photo, video, or file-upload field is implemented.
