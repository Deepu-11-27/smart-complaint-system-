import os, io, csv, smtplib
from datetime import datetime
from email.message import EmailMessage
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
import qrcode

load_dotenv()
BASE=os.path.abspath(os.path.dirname(__file__))
app=Flask(__name__)
app.config["SECRET_KEY"]=os.getenv("SECRET_KEY","dev-change-me")
app.config["SQLALCHEMY_DATABASE_URI"]="sqlite:///"+os.path.join(BASE,"instance","complaints.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"]=False
db=SQLAlchemy(app)

CATEGORIES=["Faculty Issue","Teaching Issue","Staff Issue","Classroom Issue","Laboratory Issue","Examination Issue","Academic Issue","Infrastructure Issue","Library Issue","Hostel Issue","Canteen Issue","Internet/Wi-Fi Issue","Electrical Issue","Water/Sanitation Issue","Safety/Security Issue","Transportation Issue","Administration Issue","Other"]
PRIORITIES=["Low","Medium","High","Emergency"]
STATUSES=["Pending","Under Review","In Progress","Resolved","Rejected"]

class Admin(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    username=db.Column(db.String(120),unique=True,nullable=False)
    password_hash=db.Column(db.String(255),nullable=False)

class Location(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    name=db.Column(db.String(150),unique=True,nullable=False)

class Complaint(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    complaint_id=db.Column(db.String(40),unique=True,index=True,nullable=False)
    category=db.Column(db.String(100))
    faculty_staff_name=db.Column(db.String(150))
    description=db.Column(db.Text,nullable=False)
    location=db.Column(db.String(150),nullable=False)
    specific_location=db.Column(db.String(150))
    priority=db.Column(db.String(30),nullable=False,default="Medium")
    status=db.Column(db.String(30),nullable=False,default="Pending")
    admin_response=db.Column(db.Text)
    created_at=db.Column(db.DateTime,default=datetime.utcnow)
    updated_at=db.Column(db.DateTime,default=datetime.utcnow,onupdate=datetime.utcnow)

class ComplaintStatusHistory(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    complaint_id=db.Column(db.Integer,db.ForeignKey("complaint.id"),nullable=False)
    status=db.Column(db.String(30),nullable=False)
    note=db.Column(db.Text)
    created_at=db.Column(db.DateTime,default=datetime.utcnow)

def new_id():
    import secrets
    return f"CMP-{datetime.utcnow().year}-{secrets.token_hex(3).upper()}"

def admin_required(f):
    @wraps(f)
    def w(*a,**k):
        if not session.get("admin_id"): return redirect(url_for("admin_login"))
        return f(*a,**k)
    return w

def notify(c):
    host=os.getenv("SMTP_HOST"); user=os.getenv("SMTP_USERNAME"); pw=os.getenv("SMTP_PASSWORD"); to=os.getenv("ADMIN_EMAIL")
    if not all([host,user,pw,to]): return
    msg=EmailMessage()
    msg["Subject"]=f"New Complaint Received - {c.complaint_id}"; msg["From"]=user; msg["To"]=to
    msg.set_content(f"""Complaint ID: {c.complaint_id}
Category: {c.category or "Not selected"}
Description: {c.description}
Location: {c.location}
Priority: {c.priority}
Date: {c.created_at:%Y-%m-%d %H:%M:%S}
Faculty/Staff: {c.faculty_staff_name or "Not provided"}""")
    try:
        with smtplib.SMTP(host,int(os.getenv("SMTP_PORT","587"))) as s:
            if os.getenv("SMTP_USE_TLS","true").lower()=="true": s.starttls()
            s.login(user,pw); s.send_message(msg)
    except Exception as e: app.logger.error("SMTP error: %s",e)

@app.route("/")
def index(): return render_template("index.html")

@app.route("/complaint",methods=["GET","POST"])
def complaint():
    loc=(request.args.get("location") or request.form.get("location") or "").strip()
    if request.method=="POST":
        desc=request.form.get("description","").strip()
        if not 10<=len(desc)<=5000:
            flash("Description must be between 10 and 5000 characters.","danger")
            return render_template("complaint.html",location=loc,categories=CATEGORIES,priorities=PRIORITIES)
        cid=new_id()
        while Complaint.query.filter_by(complaint_id=cid).first(): cid=new_id()
        c=Complaint(complaint_id=cid,category=request.form.get("category") or None,
            faculty_staff_name=request.form.get("faculty_staff_name","").strip() or None,
            description=desc,location=loc or "Not specified",
            priority=request.form.get("priority") or "Medium")
        db.session.add(c); db.session.flush()
        db.session.add(ComplaintStatusHistory(complaint_id=c.id,status="Pending",note="Complaint submitted"))
        db.session.commit(); notify(c)
        return redirect(url_for("success",complaint_id=cid))
    return render_template("complaint.html",location=loc,categories=CATEGORIES,priorities=PRIORITIES)

@app.route("/success/<complaint_id>")
def success(complaint_id): return render_template("success.html",complaint_id=complaint_id)

@app.route("/track",methods=["GET","POST"])
def track():
    c=None
    if request.method=="POST":
        c=Complaint.query.filter_by(complaint_id=request.form.get("complaint_id","").strip()).first()
        if not c: flash("Complaint ID not found.","danger")
    return render_template("track.html",complaint=c)

@app.route("/admin/login",methods=["GET","POST"])
def admin_login():
    if request.method=="POST":
        a=Admin.query.filter_by(username=request.form.get("username","")).first()
        if a and check_password_hash(a.password_hash,request.form.get("password","")):
            session["admin_id"]=a.id; return redirect(url_for("dashboard"))
        flash("Invalid credentials.","danger")
    return render_template("admin/login.html")

@app.route("/admin/logout")
def admin_logout(): session.clear(); return redirect(url_for("admin_login"))

@app.route("/admin/dashboard")
@admin_required
def dashboard():
    counts={s:Complaint.query.filter_by(status=s).count() for s in STATUSES}
    return render_template("admin/dashboard.html",total=Complaint.query.count(),counts=counts,high=Complaint.query.filter(Complaint.priority.in_(["High","Emergency"])).count())

@app.route("/admin/complaints")
@admin_required
def complaints():
    q=request.args.get("q","").strip(); query=Complaint.query
    if q: query=query.filter(db.or_(Complaint.complaint_id.ilike(f"%{q}%"),Complaint.description.ilike(f"%{q}%"),Complaint.faculty_staff_name.ilike(f"%{q}%")))
    if request.args.get("category"): query=query.filter_by(category=request.args["category"])
    if request.args.get("status"): query=query.filter_by(status=request.args["status"])
    if request.args.get("priority"): query=query.filter_by(priority=request.args["priority"])
    return render_template("admin/complaints.html",complaints=query.order_by(Complaint.created_at.desc()).all(),categories=CATEGORIES,statuses=STATUSES,priorities=PRIORITIES)

@app.route("/admin/complaints/<int:id>",methods=["GET","POST"])
@admin_required
def complaint_detail(id):
    c=Complaint.query.get_or_404(id)
    if request.method=="POST":
        status=request.form.get("status",c.status); response=request.form.get("admin_response","").strip()
        if status!=c.status: db.session.add(ComplaintStatusHistory(complaint_id=c.id,status=status,note=response))
        c.status=status; c.admin_response=response or None; db.session.commit(); flash("Complaint updated.","success")
    return render_template("admin/complaint_detail.html",complaint=c,statuses=STATUSES)

@app.route("/admin/locations",methods=["GET","POST"])
@admin_required
def locations():
    if request.method=="POST":
        name=request.form.get("name","").strip()
        if name and not Location.query.filter_by(name=name).first(): db.session.add(Location(name=name)); db.session.commit()
        return redirect(url_for("locations"))
    return render_template("admin/locations.html",locations=Location.query.order_by(Location.name).all())

@app.route("/admin/locations/delete/<int:id>",methods=["POST"])
@admin_required
def delete_location(id):
    db.session.delete(Location.query.get_or_404(id)); db.session.commit(); return redirect(url_for("locations"))

@app.route("/admin/qr-codes")
@admin_required
def qr_codes(): return render_template("admin/qr_codes.html",locations=Location.query.order_by(Location.name).all())

@app.route("/admin/qr/<int:id>")
@admin_required
def qr(id):
    l=Location.query.get_or_404(id); img=qrcode.make(request.host_url.rstrip("/")+"/complaint?location="+l.name)
    b=io.BytesIO(); img.save(b,"PNG"); b.seek(0)
    return send_file(b,mimetype="image/png",download_name=l.name.replace(" ","_")+".png")

@app.route("/admin/reports")
@admin_required
def reports():
    bc={}; bl={}
    for c in Complaint.query:
        bc[c.category or "Uncategorized"]=bc.get(c.category or "Uncategorized",0)+1
        bl[c.location]=bl.get(c.location,0)+1
    return render_template("admin/reports.html",by_category=bc,by_location=bl)

@app.route("/admin/export.csv")
@admin_required
def export_csv():
    b=io.StringIO(); w=csv.writer(b)
    w.writerow(["Complaint ID","Date","Time","Category","Faculty/Staff Name","Description","Location","Priority","Status","Admin Response"])
    for c in Complaint.query.order_by(Complaint.created_at.desc()):
        w.writerow([c.complaint_id,c.created_at.date(),c.created_at.time(),c.category or "",c.faculty_staff_name or "",c.description,c.location,c.priority,c.status,c.admin_response or ""])
    out=io.BytesIO(b.getvalue().encode()); return send_file(out,mimetype="text/csv",as_attachment=True,download_name="complaints.csv")

with app.app_context():
    db.create_all()
    if not Admin.query.first():
        db.session.add(Admin(username="admin",password_hash=generate_password_hash("admin123"))); db.session.commit()
        print("Default admin: admin / admin123. CHANGE IT BEFORE DEPLOYMENT.")

if __name__=="__main__": app.run(debug=True)
